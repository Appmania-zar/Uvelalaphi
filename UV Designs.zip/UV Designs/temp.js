document.addEventListener('DOMContentLoaded', function () {
    const template = document.getElementById('editableTemplate');
    let draggedElement = null;

    template.addEventListener('mousedown', function (e) {
        if (e.target.classList.contains('editable')) {
            draggedElement = e.target;
            e.preventDefault();
        }
    });

    template.addEventListener('mousemove', function (e) {
        if (draggedElement) {
            draggedElement.style.position = 'absolute';
            draggedElement.style.left = e.pageX - draggedElement.offsetWidth / 2 + 'px';
            draggedElement.style.top = e.pageY - draggedElement.offsetHeight / 2 + 'px';
        }
    });

    template.addEventListener('mouseup', function () {
        if (draggedElement) {
            draggedElement.style.position = '';
            draggedElement.style.left = '';
            draggedElement.style.top = '';
            draggedElement = null;
        }
    });

    template.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        if (!draggedElement) {
            const newElement = createEditableElement();
            newElement.style.position = 'absolute';
            newElement.style.left = e.pageX + 'px';
            newElement.style.top = e.pageY + 'px';
            template.appendChild(newElement);
            newElement.contentEditable = true;
            newElement.focus();
        }
    });

    function createEditableElement() {
        const newElement = document.createElement('div');
        newElement.className = 'editable';
        newElement.innerText = 'New Text Box';
        return newElement;
    }

    document.addEventListener('selectstart', function (e) {
        if (draggedElement) {
            e.preventDefault();
        }
    });
});